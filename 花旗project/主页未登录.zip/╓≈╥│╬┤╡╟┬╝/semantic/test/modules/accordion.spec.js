describe("UI Accordion", function() {

  $.fn.dimmer.settings.debug = false;

  moduleTests({
    module  : 'accordion',
    element : '.ui.accordion'
  });

});