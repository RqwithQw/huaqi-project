window.onload = function() {
	$('.menu .item').tab();
}

