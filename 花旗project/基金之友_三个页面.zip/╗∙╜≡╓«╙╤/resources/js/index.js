window.onload = function() {
	$('.menu .item').tab();
	$('.ui.checkbox').checkbox('attach events', '.toggle.button');
}

